vti_encoding:SR|utf8-nl
vti_author:SR|corexbd
vti_modifiedby:SR|corexbd
vti_timelastmodified:TR|16 Jan 2008 21:24:30 -0000
vti_timecreated:TR|16 Jan 2008 19:43:00 -0000
vti_extenderversion:SR|5.0.2.2634
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|16 Jan 2008 19:43:00 -0000
vti_cacheddtm:TX|16 Jan 2008 21:24:30 -0000
vti_filesize:IR|922
