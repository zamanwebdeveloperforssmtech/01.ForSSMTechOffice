<p align="center">Please wait loading...</p>
<div style="display:block">

<?php
include('dpex_main.php');
?>

</div>

<script>
//document.frmTrack.submit();
</script>