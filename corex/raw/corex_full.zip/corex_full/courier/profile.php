<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Courier Service</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
</head>
<body id="top">
<!-- ####################################################################################################### -->
<div class="wrapper col1">
  <div id="header">
    <div class="fl_left">
      <h1 align="center"><a href="#">Courier Service</a></h1>
      <p align="center">Fast and Fastest Courier</p>
      <div id="search">
       
      </div>
    </div>
    <div id="topnav">
      <ul>
        <li><a class="active" href="index.php">Home</a>
        
        </li>
        <li><a href="mv.php">Mission & Vision</a>
         
        </li>
        <li><a href="cmassage.php">Chairman's Message</a>
         
        </li>
        <li class="last"><a href="profile.php">Company Profile</a>        </li>
		
      </ul>
    </div>
    <br class="clear" />
  </div>
</div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col2">
  <div id="breadcrumb"></div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col3">
  <div id="container">
    <div id="content">
      <h1> Company Profile</h1><img class="imgr" src="images/company-profile.gif" alt="" width="210" height="232" />
      <p align="justify">Attention to the Basics
Has Earned SCS
Domestic & International Trust.

There are basic principles that we consistently uphold:

<br />
<br />
* Speed-Why use a Courier Service if the item won�t arrive quickly? Our streamlined network ensures the fastest possible movement of documents and packages.
<br />
<br />
* Reliability-The SCS system of security checks and emergency back-ups is absolutely complete. Thanks to computerized administration and a staff that is second to none.
<br />
<br />
* Low Cost-All rates are quite reasonable, even for heavy/lightweight items, fragile articles or bulky printed materials.
<br />
<br />
* Simplicity-One telephone call is all it takes to set the process in motion. After that you can leave everything to us, including customs clearance and any last minute details.</p>
      <p>&nbsp;</p>
      <div id="respond"></div>
    </div>
    <div id="column">
      <div class="subnav">
        <h2>Our Services</h2>
   
           <li><a href="service.php">General Booking service</a></li>
          <li><a href="service.php">Express Booking Service</a>
          
        <li><a href="service.php">Super Express Booking Service</a></li>
              <li><a href="service.php">Value Declared Service (V.D)</a></li>
            
          </li>
          <li><a href="service.php">Parcel Service</a>
            
        <li><a href="service.php">Air Parcel Service</a></li>
              <li><a href="service.php">Fast service</a>
             
               
          
             
          </li>
          
      </div>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<?php include("footer.php"); ?>
</body>
</html>
