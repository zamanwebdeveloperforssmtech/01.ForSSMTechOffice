<div class="wrapper col1">
  <div id="header">
    <div class="fl_left">
      <h1 align="center"><a href="#">Courier Service</a></h1>
      <p align="center">Fast and Fastest Courier</p>
      <div id="search">
       
      </div>
    </div>
    <div id="topnav">
      <ul>
        <li><a class="active" href="index.php">Home</a>
        
        </li>
        <li><a href="mv.php">Mission & Vision</a>
         
        </li>
        <li><a href="cmassage.php">Chairman's Message</a>
         
        </li>
        <li class="last"><a href="profile.php">Company Profile</a>
         
        </li>
		
      </ul>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col2">
  <div id="featured_slide">
   <?php include("slider.html"); ?>
    </div>
    <br class="clear" />
  </div>
</div>