<div class="wrapper col4">
  <div id="footer">
    <div class="footbox">
      <h2>Tracking</h2>
      <p>Please Input your 14 digit Booking Number</p>
      <form action="#" method="post">
        <fieldset>
          <legend>News Letter</legend>
          <input type="text" value="Tracking"  onfocus="this.value=(this.value=='Enter Email Here&hellip;')? '' : this.value ;" />
          <input type="submit" name="news_go" id="news_go" value="GO" />
        </fieldset>
      </form>
      <p>To unsubscribe please <a href="#">click here &raquo;</a></p>
    </div>
    <div class="footbox">
      <h2>Office/Brnches</h2>
      <ul>
        <li><a href="#">&raquo; Lorem ipsum dolor sit amet, conse</a></li>
        <li><a href="#">&raquo; Phasellus tempor vestibulum odio</a></li>
        <li><a href="#">&raquo; Vestibulum quis augue id mauris</a></li>
        <li class="last"><a href="#">&raquo; Duis egestas elit at erat imperdiet</a></li>
      </ul>
    </div>
    <div class="footbox last">
      <h2>Contact us</h2>
      <address>
      Courier Service<br />
      Street Name &amp; Number<br />
      Town<br />
      Postcode/Zip<br />
      </address>
      Tel: 000000
      <!-- -->
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col5">
  <div id="copyright">
    <p class="fl_left">Copyright &copy; 2014 - All Rights Reserved - <a href="#">Courier Service</a></p>
    <p class="fl_right">Powered by  <a href="#">SSM Technology</a></p>
    <br class="clear" />
  </div>
</div>