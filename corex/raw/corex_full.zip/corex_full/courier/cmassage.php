<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Courier Service</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" /></head>
<body id="top">
<!-- ####################################################################################################### -->
<div class="wrapper col1">
  <div id="header">
    <div class="fl_left">
      <h1 align="center"><a href="#">Courier Service</a></h1>
      <p align="center">Fast and Fastest Courier</p>
      <div id="search">
       
      </div>
    </div>
    <div id="topnav">
      <ul>
        <li><a class="active" href="index.php">Home</a>
        
        </li>
        <li><a href="mv.php">Mission & Vision</a>
         
        </li>
        <li><a href="cmassage.php">Chairman's Message</a>
         
        </li>
        <li class="last"><a href="profile.php">Company Profile</a>
         
        </li>
		
      </ul>
    </div>
    <br class="clear" />
  </div>
</div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col2">
  <div id="breadcrumb"></div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col3">
  <div id="container">
    <div id="content">
      <h1>Chairman�s Message</h1>
      <img class="imgr" src="images/demo/imgr.gif" alt="" width="125" height="125" />
      <h3>Courier Service of Companies means Reliability, Continuity and Dependability.</h3>
      <br />
      <p align="justify">I&nbsp;<strong>Name</strong>, proud of our belief in such principles, which have charted our growth across more than 27 years.</p>
      <p align="justify">Today, Courier Service of Companies operates extensively worldwide with its own offices in Bangladesh and Malaysia. An increasingly diverse range of products and services are produced, marketed and distributed by the group. Our expanding commercial diversification continues to be directed by educated trained up executives located all over Bangladesh in operation. Executive direction is supported by experienced Management selected locally in each operating area. Together our executive teams are responsible to maintain our company at the forefront of Management skills and development of computerized information technology systems.</p>
      <p align="justify">Throughout our history of growth and diversification emphasis has focused upon retaining traditional business values which remain at the center of our relationships with customers and suppliers. Thus, 27 years of tradition combined with advanced business efficiency and management kept us close to our clients and market. We are dedicated to serve our community and support its needs.</p>
      <p align="justify">We remain committed in continuing to provide reliable and dependable services to our business clients and individuals.</p>
      <br />
      <p><strong>Name</strong><br />
          <strong>Chairman</strong><br />
      <strong>Courier Service</strong></p>
      <p>&nbsp;</p>
    </div>
    <div id="column">
      <div class="subnav">
            <h2>Our Services</h2>
   
           <li><a href="service.php">General Booking service</a></li>
          <li><a href="service.php">Express Booking Service</a>
          
        <li><a href="service.php">Super Express Booking Service</a></li>
              <li><a href="service.php">Value Declared Service (V.D)</a></li>
            
          </li>
          <li><a href="service.php">Parcel Service</a>
            
        <li><a href="service.php">Air Parcel Service</a></li>
              <li><a href="service.php">Fast service</a>
             
               
          
             
          </li>
      </div>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<?php include("footer.php"); ?>
</body>
</html>
