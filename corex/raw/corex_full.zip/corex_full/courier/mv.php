<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Courier Service</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
</head>
<body id="top">
<!-- ####################################################################################################### -->
<div class="wrapper col1">
  <div id="header">
    <div class="fl_left">
      <h1 align="center"><a href="#">Courier Service</a></h1>
      <p align="center">Fast and Fastest Courier</p>
      <div id="search">
       
      </div>
    </div>
    <div id="topnav">
      <ul>
        <li><a class="active" href="index.php">Home</a>
        
        </li>
        <li><a href="mv.php">Mission & Vision</a>
         
        </li>
        <li><a href="cmassage.php">Chairman's Message</a>
         
        </li>
        <li class="last"><a href="profile.php">Company Profile</a>
         
        </li>
		
      </ul>
    </div>
    <br class="clear" />
  </div>
</div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col2">
  <div id="breadcrumb"></div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col3">
  <div id="container">
    <div id="content">
      <h1>Our Mission & Vision</h1>
      <img class="imgr" src="images/vision.png" alt="" width="220" height="248" />
      <p align="justify">Our Business Strategy has demanding and realistic targets.</p>
      <br />
      <p align="justify">We boast of a strong wide coverage backed by our solid ground support and a solid administrative team to promote customers with the best experience possible.</p>
      <br />
      <p align="justify">We have a continuous goal to radically improve speed to Courier Market in Bangladesh.</p>
      <br />
      <p>We have a realistic understanding of what of our competitors.</p>
      <br />
      <p>We explore modern technologies and research to drive new product service.</p>
      <br />
      <p align="justify">We create paths for unemployed youth providing jobs which are a tremendous help and financial support to improve the social and economical condition of our country.</p>
      <div id="respond"><form action="#" method="post">
      </form>
      </div>
    </div>
    <div id="column">
      <div class="subnav">
          <h2>Our Services</h2>
   
          <li><a href="service.php">General Booking service</a></li>
          <li><a href="service.php">Express Booking Service</a>
          
        <li><a href="service.php">Super Express Booking Service</a></li>
              <li><a href="service.php">Value Declared Service (V.D)</a></li>
            
          </li>
          <li><a href="service.php">Parcel Service</a>
            
        <li><a href="service.php">Air Parcel Service</a></li>
              <li><a href="service.php">Fast service</a>
             
               
          
             
          </li>
      </div>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<?php include("footer.php"); ?>
</body>
</html>
